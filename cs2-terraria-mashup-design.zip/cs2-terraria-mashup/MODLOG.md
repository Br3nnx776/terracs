# MODLOG: Dust2 in Terraria (working title)

Status: DESIGN ONLY. Nothing is built, installed, tested or published. No game files were available in this workspace and Melty could not be reached (see Blockers).

## The idea (agreed with the player)
- A Terraria world shaped like the Counter-Strike 2 map Dust2. The player explores, mines and builds freely; Terraria enemies spawn and come straight at them.
- First version: Dust2-shaped world, three CS2 guns (Glock-18 to start, AK-47 and AWP by crafting) with their real icons and sounds, plus enemies that rush the player.
- Solo only. Others may remix it (license family chosen: open, credit required).

## Roles
- Terraria: host (role "primary"). The player launches it.
- Counter-Strike 2: companion. Its map, icons and sounds are read from the player's own install at runtime. CS2 is never launched, hooked or modified, and nothing from it is copied into Terraria or into the upload.

## Route
- tModLoader mod in C#, reading CS2 files with ValveResourceFormat (MIT) opened read-only on the folder Melty passes in (env DUST2TERRARIA_CS2_DIR = {game:counter-strike-2}).
- World: ModSystem.ModifyWorldGenTasks builds terrain from the Dust2 map when the player creates a world.
- Guns: one ModItem per row of sheets/weapons.json; icon and sounds are decoded in memory, never written to disk.
- Enemies: GlobalNPC spawn hooks per sheets/enemies.json.
- Fallback if tModLoader cannot be delivered in one click: a hook or proxy DLL route into vanilla Terraria (heavier; not started).

## Blockers (why preflight is not clean)
1. melty.gg is blocked by this session's network policy (403 on CONNECT). No game_info, search_mashups, validate_recipe, one_click_check or upload could run. Not retried or routed around.
2. Neither game is installed on this workspace, so no file listing, no build, no test, no screenshot.
3. Melty's notes say it installs no loader for Terraria and players would have to install tModLoader by hand. tModLoader is MIT and listed on Steam (app 1281930); whether it may be bundled and how it would be delivered is unverified. This decides whether one_click_check can pass. The player must be told before building if it cannot.
4. No dotnet SDK here, so no C# could be compiled even in principle.

## Open design questions (cells still null in the sheets)
- How a 3D map becomes a 2D side-on world ("unfolded-route" is the working choice: route waypoints, surface classifier and spawn point are not decided).
- Exact archive and file paths for CS2 weapon icons and sounds (need a listing of the real install).
- Whether units_per_tile = 12 gives playable corridors for Terraria's player size.
- Credits line for the listing.

## Evidence levels
- Documented, not seen: CS2 maps ship as a VPK under maps/ with maps/<name>.vmap_c inside (Source 2 Viewer guide). ValveResourceFormat is MIT. tModLoader is MIT, Steam app 1281930.
- Seen on a real install: nothing.

## Risks to check on the real machine
- The generated world is a Terraria save derived from CS2 map data. Policy here is generate-on-create, keep only in the player's own Worlds folder, never upload. Confirm this counts as reading, not copying.
- Plain sand blocks fall; floors use hardened sand.
- Every Terraria tile and NPC name in the sheets is symbolic and unchecked against the game.

## Next steps (on a machine with both games and Melty access)
1. Connect to Melty; run game_info for both games and search_mashups; run list_my_mods.
2. List the real CS2 install, fill the null cells in sheets/sources.json, then decide the projection.
3. Run tools/preflight.py until clean; only then build.
4. Vertical slice: world with one corridor, one gun firing with its real sound, one enemy approaching. Test in the running game.
5. Package, validate_recipe, one_click_check, screenshot, test_release, then ask before publish.
