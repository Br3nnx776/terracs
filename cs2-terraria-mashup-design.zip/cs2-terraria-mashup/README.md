# Dust2 in Terraria (working title)

> STATUS: design only. Not built, not tested, not published. See MODLOG.md for what is blocking it.

A Terraria world shaped like Dust2, with Counter-Strike 2's guns. Explore, mine and build across the map while Terraria's enemies come straight at you.

## What players get (planned first version)
- A Terraria world generated from the Dust2 map in your own Counter-Strike 2 install.
- Three CS2 guns with their real icons and sounds: Glock-18 (you start with it), AK-47 and AWP (craft them).
- Terraria enemies that spawn near you and rush you.
- Solo play.

## You need
- Terraria and Counter-Strike 2, both installed on the same PC.
- tModLoader (how it will be delivered in one click is still open).

## How it works
The mod runs inside Terraria. It reads Dust2 and the gun icons and sounds from your CS2 folder, read-only. Counter-Strike 2 is never started or changed, and none of its files are copied or shipped with the mod.

## Layout
- sheets/: the design, one JSON sheet per system. The sheets are the source of truth.
- tools/preflight.py: lists unfilled cells, unresolved references and unchecked cells. Build only when it is clean.
- MODLOG.md: route, blockers and next steps.

## License
Open, credit required, remix allowed. A formal license text and the credits line are still to be chosen.
