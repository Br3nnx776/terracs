#!/usr/bin/env python3
"""Preflight: lay every sheet over the others and list what would fail.

Usage: python3 tools/preflight.py [project_dir]

Exit code 0 only when nothing is unfilled, no reference is unresolved, no
dependency loops, and every filled cell is listed in its row's "_checked"
(meaning it was verified against the real game files or confirmed by the player).
Build only when this is clean.
"""
import json
import sys
from pathlib import Path

NA = "n/a"


def load(project):
    sheets = {}
    for path in sorted((project / "sheets").glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        sheets[data["sheet"]] = data
    return sheets


def is_empty(value):
    return value is None or value == "" or value == []


def find_cycles(sheets):
    graph = {}
    for row in sheets.get("systems", {"rows": []})["rows"]:
        deps = row.get("depends_on")
        graph[row["id"]] = [] if is_empty(deps) or deps == NA else list(deps)
    cycles, state = [], {}

    def visit(node, trail):
        state[node] = 1
        for nxt in graph.get(node, []):
            if state.get(nxt) == 1:
                cycles.append(" -> ".join(trail + [node, nxt]))
            elif nxt not in state:
                visit(nxt, trail + [node])
        state[node] = 2

    for node in graph:
        if node not in state:
            visit(node, [])
    return cycles


def main():
    project = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    sheets = load(project)
    ids = {name: {row["id"] for row in sheet["rows"]} for name, sheet in sheets.items()}

    unfilled, unresolved, unchecked = [], [], []
    for name, sheet in sheets.items():
        for row in sheet["rows"]:
            checked = set(row.get("_checked", []))
            for col, typ in sheet["columns"].items():
                value = row.get(col)
                where = f"{name}.{row['id']}.{col}"
                if is_empty(value):
                    unfilled.append(where)
                    continue
                if value == NA:
                    continue
                if "ref:" in typ:
                    target = typ.split("ref:")[1]
                    for item in value if isinstance(value, list) else [value]:
                        if item not in ids.get(target, set()):
                            unresolved.append(f"{where} -> {target}:{item}")
                if col != "id" and col not in checked:
                    unchecked.append(where)

    cycles = find_cycles(sheets)
    lines = []

    def section(title, items):
        lines.append(f"\n== {title}: {len(items)}")
        lines.extend("  " + item for item in items)

    section("Unfilled cells (nothing to build from)", unfilled)
    section("Unresolved references", unresolved)
    section("Dependency loops", cycles)
    section("Unchecked cells (filled, not yet verified against the real files)", unchecked)
    clean = not (unfilled or unresolved or cycles or unchecked)
    lines.append("\nPREFLIGHT " + ("CLEAN: ok to build" if clean else "NOT CLEAN: do not build yet"))
    report = "\n".join(lines)
    (project / "preflight_report.txt").write_text(report + "\n", encoding="utf-8")

    rows_total = sum(len(s["rows"]) for s in sheets.values())
    print(f"{len(sheets)} sheets, {rows_total} rows")
    for title, items in (("unfilled", unfilled), ("unresolved", unresolved), ("loops", cycles), ("unchecked", unchecked)):
        print(f"  {title}: {len(items)}")
    if unfilled:
        print("\nUnfilled cells:")
        print("\n".join("  " + item for item in unfilled))
    if unresolved:
        print("\nUnresolved references:")
        print("\n".join("  " + item for item in unresolved))
    if cycles:
        print("\nDependency loops:")
        print("\n".join("  " + item for item in cycles))
    print("\nFull report: preflight_report.txt")
    print("PREFLIGHT " + ("CLEAN" if clean else "NOT CLEAN"))
    return 0 if clean else 1


if __name__ == "__main__":
    sys.exit(main())
